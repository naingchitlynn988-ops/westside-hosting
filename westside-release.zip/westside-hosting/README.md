# WESTSIDE Hosting — website preview

A responsive Aternos-inspired Minecraft hosting dashboard concept using a red/black WESTSIDE visual identity.

## Run locally
1. Extract the ZIP.
2. Open `index.html` in a modern browser, or serve this folder with any static web server.
3. No build step or package installation is required.

## What's included
- Responsive dashboard layout
- WESTSIDE red/black branding
- 4 GB Free plan presentation
- 24/7 hosting goal presentation
- Create-server modal (demo only)
- Simulated start/stop button, uptime counter, and copy-address interaction

## Important: demo vs. real hosting
This project is a **front-end prototype only**. It does not provision Minecraft servers, provide actual 4 GB RAM, guarantee 24/7 uptime, or create a working `royyhosting.com` domain. The server address is a placeholder.

To launch a real hosting service, you still need:
- A domain registered and DNS configured for `royyhosting.com`
- A Linux host/dedicated machine with sufficient CPU, RAM, storage and network capacity
- A backend API and database for accounts, server provisioning, permissions and billing (even if plans are free)
- A safe server orchestration layer (for example, containers managed by a panel such as Pterodactyl)
- Monitoring, backups, abuse controls, firewalling and operational support

Do not expose Docker, SSH, panel admin credentials, or a server daemon directly to the browser. The frontend should call an authenticated backend API.

## Suggested next build
Implement authentication and a secure backend that provisions Minecraft servers through a managed orchestration panel. Then connect the dashboard buttons to real server status/start/stop endpoints.
